﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ST10021160.PROG.POE.PT2.Models
{
    public class SupportingDocumentsModel
    {
        [Key]
        public int Docid { get; set; }

        [Required, MaxLength(255)]
        public string Name { get; set; }

        [Required, MaxLength(255)]
        public string FilePath { get; set; }

        // Foreign key relationship with ClaimsFormModel
        public int ClaimId { get; set; }

        [ForeignKey("ClaimId")]
        public virtual ClaimsFormModel ClaimsForm { get; set; }
    }


}