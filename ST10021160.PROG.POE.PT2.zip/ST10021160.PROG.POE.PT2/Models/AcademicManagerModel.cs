﻿using System.ComponentModel.DataAnnotations;

namespace ST10021160.PROG.POE.PT2.Models
{
    public class AcademicManagerModel
    {
        [Key]
        public int Lecture_ID { get; set; }

        [Required, MaxLength(255)]
        public string FirstName { get; set; }

        [Required, MaxLength(255)]
        public string LastName { get; set; }

        [Required]
        public int Contact { get; set; }

        [Required, MaxLength(255)]
        [EmailAddress]
        public string Email { get; set; }
    }

}
