﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace ST10021160.PROG.POE.PT2.Models
{
    public class CmcsDbContext : DbContext
    {
        public DbSet<AcademicManagerModel> AcademicManagers { get; set; }
        public DbSet<ContractLecturerModel> ContractLecturers { get; set; }
        public DbSet<ClaimsFormModel> ClaimsForms { get; set; }
        public DbSet<SupportingDocumentsModel> SupportingDocuments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure relationships if needed, for example:
            modelBuilder.Entity<ClaimsFormModel>()
                .HasOne(c => c.ContractLecturer)
                .WithMany()
                .HasForeignKey(c => c.Lecture_ID);

            modelBuilder.Entity<SupportingDocumentsModel>()
                .HasOne(s => s.ClaimsForm)
                .WithMany()
                .HasForeignKey(s => s.ClaimId);
        }
    }
}
