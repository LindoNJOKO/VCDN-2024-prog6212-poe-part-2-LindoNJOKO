﻿using Microsoft.AspNetCore.Mvc;
using ST10021160.PROG.POE.PT2.Models;
using System.Linq;
using System.Collections.Generic;

namespace ST10021160.PROG.POE.PT2.Controllers
{
    public class ClaimsFormController : Controller
    {
        private readonly CmcsDbContext _context;

        public ClaimsFormController(CmcsDbContext context)
        {
            _context = context;
        }

        // GET: ClaimsForm
        public IActionResult Index()
        {
            return View();
        }

        // GET: ClaimsForm/Details/5
        public IActionResult Details(int id)
        {
            var claim = _context.ClaimsForms.Find(id);
            if (claim == null)
            {
                return NotFound();
            }
            return View(claim);
        }
    }


}
