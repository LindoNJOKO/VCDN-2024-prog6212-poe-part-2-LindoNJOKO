﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;
using ST10021160.PROG.POE.PT2.Models;

namespace ST10021160.PROG.POE.PT2.Controllers
{
    public class ContractLecturerController : Controller
    {
        private readonly CmcsDbContext _context;

        public ContractLecturerController(CmcsDbContext context)
        {
            _context = context;
        }

        // View Dashboard: Shows submitted claims and their status
        public IActionResult ContractLecturerDashboardView(int lecturerId)
        {
            var claims = _context.ClaimsForms
                .Where(c => c.Lecture_ID == lecturerId)
                .ToList();

            return View(claims);
        }

        // Redirect to Claims Form
        public IActionResult ClaimFormView()
        {
            return View();
        }

        // Post method to submit a new claim
        [HttpPost]
        public async Task<IActionResult> ClaimFormView(ClaimsFormModel claim)
        {
            if (ModelState.IsValid)
            {
                _context.ClaimsForms.Add(claim);
                await _context.SaveChangesAsync();
                return RedirectToAction("ContractLecturerDashboardView", new { lecturerId = claim.Lecture_ID });
            }

            // Return the model to the view with validation errors
            return View(claim);
        }

        // View details of a particular claim
        public IActionResult ViewClaim(int claimId)
        {
            var claim = _context.ClaimsForms
                .FirstOrDefault(c => c.ClaimId == claimId);

            if (claim == null)
            {
                return NotFound();
            }

            return View(claim);
        }

        // Upload supporting documents for a specific claim
        [HttpPost]
        public async Task<IActionResult> UploadDocument(int claimId, IFormFile file)
        {
            if (file != null && (file.FileName.EndsWith(".docx") || file.FileName.EndsWith(".xlsx") || file.FileName.EndsWith(".pdf")))
            {
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", file.FileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                var document = new SupportingDocumentsModel
                {
                    Name = file.FileName,
                    FilePath = filePath,
                    ClaimId = claimId
                };

                _context.SupportingDocuments.Add(document);
                await _context.SaveChangesAsync();

                return RedirectToAction("ViewClaim", new { claimId = claimId });
            }

            ModelState.AddModelError("", "Invalid file type. Only .docx, .xlsx, or .pdf allowed.");
            return RedirectToAction("ViewClaim", new { claimId = claimId });
        }
    }
}
