﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ST10021160.PROG.POE.PT2.Models;
using System.Linq;
using System.Threading.Tasks;

namespace ST10021160.PROG.POE.PT2.Controllers;

public class AcademicManagerController : Controller
{
    private readonly CmcsDbContext _context;

    public AcademicManagerController(CmcsDbContext context)
    {
        _context = context;
    }

    // View dashboard: Shows all submitted claims that are pending for review
    public IActionResult AcademicManagerDashboard()
    {
        var pendingClaims = _context.ClaimsForms
            .Where(c => c.Status == "Pending")
            .ToList();

        return View(pendingClaims);
    }

    // View a specific claim for approval or rejection
    public IActionResult ReviewClaim(int claimId)
    {
        var claim = _context.ClaimsForms
            .FirstOrDefault(c => c.ClaimId == claimId);

        if (claim == null)
        {
            return NotFound();
        }

        return View(claim);
    }

    // Approve a claim
    [HttpPost]
    public async Task<IActionResult> ApproveClaim(int claimId)
    {
        var claim = _context.ClaimsForms.FirstOrDefault(c => c.ClaimId == claimId);
        if (claim == null)
        {
            return NotFound();
        }

        claim.Status = "Approved";
        _context.ClaimsForms.Update(claim);
        await _context.SaveChangesAsync();

        return RedirectToAction("AcademicManagerDashboard");
    }

    // Reject a claim
    [HttpPost]
    public async Task<IActionResult> RejectClaim(int claimId, string rejectionReason)
    {
        var claim = _context.ClaimsForms.FirstOrDefault(c => c.ClaimId == claimId);
        if (claim == null)
        {
            return NotFound();
        }

        claim.Status = "Rejected";
        claim.AdditionalNotes = rejectionReason;
        _context.ClaimsForms.Update(claim);
        await _context.SaveChangesAsync();

        return RedirectToAction("AcademicManagerDashboard");
    }
} 
